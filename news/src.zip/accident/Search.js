import React from 'react';

const Search = () => {
  return <div className="searchBox">서치</div>;
};

export default Search;
