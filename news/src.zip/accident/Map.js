import React from 'react';

const Map = () => {
  return <div className="map">지도</div>;
};

export default Map;
